import javax.swing.plaf.basic.BasicOptionPaneUI;

public class BasicAccount implements  IAccount {

    int accountNumberm;
    double withdrawaLimitm;

    double balance;


   public BasicAccount(int accountNumber, double withdrawaLimit){

       this.accountNumberm=accountNumber;
       this.withdrawaLimitm=withdrawaLimit;
       balance=0.0;
   }

    @Override
    public void Deposit(double amount) {

       balance+= amount;
    }

    @Override
    public double Withdraw(double amount) {
       if (amount <= balance)
       {
            if (amount>this.withdrawaLimitm) {
                balance -= withdrawaLimitm;
                return withdrawaLimitm;
            }
            else {
                balance-=amount;
                return amount;
            }
       }
        return 0;
    }

    @Override
    public double GetCurrentBalance() {
        return balance;
    }

    @Override
    public int GetAccountNumber() {
        return this.accountNumberm;
    }
}
