public class StandartAccount implements IAccount{

    int accountNumberm;
    double creditLimitm;

    double balance;


    public StandartAccount(int accountNumber, double creditLimit){
        this.accountNumberm=accountNumber;
        if (creditLimit<0)
            this.creditLimitm=creditLimit;
        else
            this.creditLimitm=0;
        balance=0.0;
    }

    @Override
    public void Deposit(double amount) {
        balance+=amount;

    }

    @Override
    public double Withdraw(double amount) {
        if (balance >= amount)
            return  amount ;
        else
        {
            if ((amount-balance)> -(creditLimitm))
            {
                amount=balance-creditLimitm;
                balance=creditLimitm;
                return amount ;

            }
            else
                balance= -(amount-balance);
                return amount;

        }
    }

    @Override
    public double GetCurrentBalance() {
        return balance;
    }

    @Override
    public int GetAccountNumber() {
        return this.accountNumberm;
    }
}
