public interface IAccount {

    //adds the amount provided as a double to the account balance.
    void Deposit(double amount);
    /* withdraw the requested amount from the account according to the
    account restrictions, the value returned is the actual amount that has been
    withdrawn as a double */
    double Withdraw(double amount);
   //return the current account’s balance as double.
    double GetCurrentBalance();
    //returns the account number as an integer
    int GetAccountNumber();
}
