import java.util.ArrayList;
import java.util.List;

public class Bank implements IBank{

    List<IAccount> IBank ;
    public Bank() {
        this.IBank =new ArrayList<>();
    }
    @Override
    public void OpenAccount(IAccount account) {
        this.IBank.add(account);
    }

    @Override
    public void CloseAccount(int accountNumber) {

        for (int i=0; i<= this.IBank.size(); i++)
        {
            if (this.IBank.get(i).GetAccountNumber()==accountNumber)
            {
                double currentBalance = this.IBank.get(i).GetCurrentBalance();
                if (currentBalance>=0) {
                    this.IBank.remove(i);
                }
                else {
                    System.out.println("The account is not closed due to debt.");
                }

            }

        }
    }

    @Override
    public List<IAccount> GetAllAccounts() {

        return this.IBank;
    }

    @Override
    public List<IAccount> GetAllAccountsInDebt() {
        List<IAccount> IBankDebt = new ArrayList<>() ;
        for (int i=0; i<= this.IBank.size(); i++)
        {
            double currentBalance = this.IBank.get(i).GetCurrentBalance();
            if (currentBalance<0) {
                    IBankDebt.add(this.IBank.get(i));
                }

        }
        return IBankDebt;
    }

    @Override
    public List<IAccount> GetAllAccountsWithBalance(double balanceAbove) {
        List<IAccount> IBankBalance = new ArrayList<>();

        for(int i=0; i<= this.IBank.size(); i++)
        {
            double currentBalance = this.IBank.get(i).GetCurrentBalance();
            if (currentBalance>=balanceAbove) {
                IBankBalance.add(this.IBank.get(i));
            }



        }
        return IBankBalance;
    }
}
